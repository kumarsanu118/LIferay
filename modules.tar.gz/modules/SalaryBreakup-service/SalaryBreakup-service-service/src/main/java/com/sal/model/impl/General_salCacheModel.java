/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.sal.model.impl;

import aQute.bnd.annotation.ProviderType;

import com.liferay.portal.kernel.model.CacheModel;
import com.liferay.portal.kernel.util.HashUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;

import com.sal.model.General_sal;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing General_sal in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see General_sal
 * @generated
 */
@ProviderType
public class General_salCacheModel implements CacheModel<General_sal>,
	Externalizable {
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof General_salCacheModel)) {
			return false;
		}

		General_salCacheModel general_salCacheModel = (General_salCacheModel)obj;

		if (salaryId == general_salCacheModel.salaryId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, salaryId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", salaryId=");
		sb.append(salaryId);
		sb.append(", employeeId=");
		sb.append(employeeId);
		sb.append(", breakUpType=");
		sb.append(breakUpType);
		sb.append(", amount=");
		sb.append(amount);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public General_sal toEntityModel() {
		General_salImpl general_salImpl = new General_salImpl();

		if (uuid == null) {
			general_salImpl.setUuid(StringPool.BLANK);
		}
		else {
			general_salImpl.setUuid(uuid);
		}

		general_salImpl.setSalaryId(salaryId);
		general_salImpl.setEmployeeId(employeeId);

		if (breakUpType == null) {
			general_salImpl.setBreakUpType(StringPool.BLANK);
		}
		else {
			general_salImpl.setBreakUpType(breakUpType);
		}

		general_salImpl.setAmount(amount);

		general_salImpl.resetOriginalValues();

		return general_salImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		salaryId = objectInput.readLong();

		employeeId = objectInput.readLong();
		breakUpType = objectInput.readUTF();

		amount = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(salaryId);

		objectOutput.writeLong(employeeId);

		if (breakUpType == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(breakUpType);
		}

		objectOutput.writeLong(amount);
	}

	public String uuid;
	public long salaryId;
	public long employeeId;
	public String breakUpType;
	public long amount;
}