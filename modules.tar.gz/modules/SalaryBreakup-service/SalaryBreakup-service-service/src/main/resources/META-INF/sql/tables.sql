create table FOO_General_sal (
	uuid_ VARCHAR(75) null,
	salaryId LONG not null primary key,
	employeeId LONG,
	breakUpType VARCHAR(75) null,
	amount LONG
);