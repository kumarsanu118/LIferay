create index IX_D2DA10B1 on FOO_General_sal (employeeId);
create index IX_A1DE9520 on FOO_General_sal (uuid_[$COLUMN_LENGTH:75$]);