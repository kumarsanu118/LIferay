/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.sal.model;

import aQute.bnd.annotation.ProviderType;

import com.liferay.expando.kernel.model.ExpandoBridge;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.service.ServiceContext;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * This class is a wrapper for {@link General_sal}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see General_sal
 * @generated
 */
@ProviderType
public class General_salWrapper implements General_sal,
	ModelWrapper<General_sal> {
	public General_salWrapper(General_sal general_sal) {
		_general_sal = general_sal;
	}

	@Override
	public Class<?> getModelClass() {
		return General_sal.class;
	}

	@Override
	public String getModelClassName() {
		return General_sal.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("salaryId", getSalaryId());
		attributes.put("employeeId", getEmployeeId());
		attributes.put("breakUpType", getBreakUpType());
		attributes.put("amount", getAmount());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long salaryId = (Long)attributes.get("salaryId");

		if (salaryId != null) {
			setSalaryId(salaryId);
		}

		Long employeeId = (Long)attributes.get("employeeId");

		if (employeeId != null) {
			setEmployeeId(employeeId);
		}

		String breakUpType = (String)attributes.get("breakUpType");

		if (breakUpType != null) {
			setBreakUpType(breakUpType);
		}

		Long amount = (Long)attributes.get("amount");

		if (amount != null) {
			setAmount(amount);
		}
	}

	@Override
	public General_sal toEscapedModel() {
		return new General_salWrapper(_general_sal.toEscapedModel());
	}

	@Override
	public General_sal toUnescapedModel() {
		return new General_salWrapper(_general_sal.toUnescapedModel());
	}

	@Override
	public boolean isCachedModel() {
		return _general_sal.isCachedModel();
	}

	@Override
	public boolean isEscapedModel() {
		return _general_sal.isEscapedModel();
	}

	@Override
	public boolean isNew() {
		return _general_sal.isNew();
	}

	@Override
	public ExpandoBridge getExpandoBridge() {
		return _general_sal.getExpandoBridge();
	}

	@Override
	public com.liferay.portal.kernel.model.CacheModel<General_sal> toCacheModel() {
		return _general_sal.toCacheModel();
	}

	@Override
	public int compareTo(General_sal general_sal) {
		return _general_sal.compareTo(general_sal);
	}

	@Override
	public int hashCode() {
		return _general_sal.hashCode();
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _general_sal.getPrimaryKeyObj();
	}

	@Override
	public java.lang.Object clone() {
		return new General_salWrapper((General_sal)_general_sal.clone());
	}

	/**
	* Returns the break up type of this general_sal.
	*
	* @return the break up type of this general_sal
	*/
	@Override
	public java.lang.String getBreakUpType() {
		return _general_sal.getBreakUpType();
	}

	/**
	* Returns the uuid of this general_sal.
	*
	* @return the uuid of this general_sal
	*/
	@Override
	public java.lang.String getUuid() {
		return _general_sal.getUuid();
	}

	@Override
	public java.lang.String toString() {
		return _general_sal.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _general_sal.toXmlString();
	}

	/**
	* Returns the amount of this general_sal.
	*
	* @return the amount of this general_sal
	*/
	@Override
	public long getAmount() {
		return _general_sal.getAmount();
	}

	/**
	* Returns the employee ID of this general_sal.
	*
	* @return the employee ID of this general_sal
	*/
	@Override
	public long getEmployeeId() {
		return _general_sal.getEmployeeId();
	}

	/**
	* Returns the primary key of this general_sal.
	*
	* @return the primary key of this general_sal
	*/
	@Override
	public long getPrimaryKey() {
		return _general_sal.getPrimaryKey();
	}

	/**
	* Returns the salary ID of this general_sal.
	*
	* @return the salary ID of this general_sal
	*/
	@Override
	public long getSalaryId() {
		return _general_sal.getSalaryId();
	}

	@Override
	public void persist() {
		_general_sal.persist();
	}

	/**
	* Sets the amount of this general_sal.
	*
	* @param amount the amount of this general_sal
	*/
	@Override
	public void setAmount(long amount) {
		_general_sal.setAmount(amount);
	}

	/**
	* Sets the break up type of this general_sal.
	*
	* @param breakUpType the break up type of this general_sal
	*/
	@Override
	public void setBreakUpType(java.lang.String breakUpType) {
		_general_sal.setBreakUpType(breakUpType);
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_general_sal.setCachedModel(cachedModel);
	}

	/**
	* Sets the employee ID of this general_sal.
	*
	* @param employeeId the employee ID of this general_sal
	*/
	@Override
	public void setEmployeeId(long employeeId) {
		_general_sal.setEmployeeId(employeeId);
	}

	@Override
	public void setExpandoBridgeAttributes(ExpandoBridge expandoBridge) {
		_general_sal.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.kernel.model.BaseModel<?> baseModel) {
		_general_sal.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(ServiceContext serviceContext) {
		_general_sal.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public void setNew(boolean n) {
		_general_sal.setNew(n);
	}

	/**
	* Sets the primary key of this general_sal.
	*
	* @param primaryKey the primary key of this general_sal
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_general_sal.setPrimaryKey(primaryKey);
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		_general_sal.setPrimaryKeyObj(primaryKeyObj);
	}

	/**
	* Sets the salary ID of this general_sal.
	*
	* @param salaryId the salary ID of this general_sal
	*/
	@Override
	public void setSalaryId(long salaryId) {
		_general_sal.setSalaryId(salaryId);
	}

	/**
	* Sets the uuid of this general_sal.
	*
	* @param uuid the uuid of this general_sal
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_general_sal.setUuid(uuid);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof General_salWrapper)) {
			return false;
		}

		General_salWrapper general_salWrapper = (General_salWrapper)obj;

		if (Objects.equals(_general_sal, general_salWrapper._general_sal)) {
			return true;
		}

		return false;
	}

	@Override
	public General_sal getWrappedModel() {
		return _general_sal;
	}

	@Override
	public boolean isEntityCacheEnabled() {
		return _general_sal.isEntityCacheEnabled();
	}

	@Override
	public boolean isFinderCacheEnabled() {
		return _general_sal.isFinderCacheEnabled();
	}

	@Override
	public void resetOriginalValues() {
		_general_sal.resetOriginalValues();
	}

	private final General_sal _general_sal;
}