package com.exp.render;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import com.exp.constants.ExpansePortletKeys;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;

@Component(property = { "javax.portlet.name=" + ExpansePortletKeys.Expanse,
"mvc.command.name=show_values" }, service = MVCRenderCommand.class)


public class ExpanseRender implements MVCRenderCommand  {

	public final static String SHOW_VALUES = "/show_values.jsp";
	public final static String ERROR = "/error.jsp";
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		System.out.println("in ShowVal ");
		try {
			String name = ParamUtil.getString(renderRequest, "name");
			System.out.println("name::::::" + name);
			renderRequest.setAttribute("name", name);
		} catch (Exception e) {
			return ERROR;
		}

		return SHOW_VALUES;
	}


}
