package com.exp.constants;

/**
 * @author e2
 */
public class ExpansePortletKeys {

	public static final String Expanse = "Expanse";

}