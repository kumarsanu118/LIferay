package com.exp.ActionCommand;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.exp.constants.ExpansePortletKeys;
import com.exp.model.Ecpanse;
import com.exp.service.EcpanseLocalService;
import com.exp.service.EcpanseLocalServiceUtil;
import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;

@Component(
		 property = {
		 "javax.portlet.name=" + ExpansePortletKeys.Expanse,
		 "mvc.command.name=saveStudDetails"
		 },
		 service = MVCActionCommand.class
		 )

public class ExpanseActionCommand extends BaseMVCActionCommand {
	

	 private EcpanseLocalService ecpanseLocalService;
	 
	 @Reference(unbind = "-")
	 protected void setexpanseService(EcpanseLocalService ecpanseLocalService){
		 this.ecpanseLocalService=ecpanseLocalService;
	 }
	 @Override
	 protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) 
	 throws Exception {
		 String name =ParamUtil.getString(actionRequest,"name");
		 long categoryId= ParamUtil.getInteger(actionRequest, "categoryId");
		 Ecpanse espance =EcpanseLocalServiceUtil.createEcpanse(CounterLocalServiceUtil.increment());
		 espance.setName(name);
		 espance.setCategoryId(categoryId);
		 EcpanseLocalServiceUtil.updateEcpanse(espance);
	 }
	 }

