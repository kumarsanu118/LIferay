package com.exp.portlet;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;

import com.exp.constants.ExpansePortletKeys;
import com.exp.model.Ecpanse;
import com.exp.service.EcpanseLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;

/**
 * @author e2
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Expanse Portlet",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + ExpansePortletKeys.Expanse,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class ExpansePortlet extends MVCPortlet {
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		List<Ecpanse> ecpanse = EcpanseLocalServiceUtil.getProjectBycompanyName("name");
		renderRequest.setAttribute("ecpanse", ecpanse);
		String companyId = ParamUtil.getString(renderRequest,"companyId");
		renderRequest.setAttribute("companyId", companyId);
		if(companyId != null){
			Ecpanse ecpanse1 =null;
			try {
				ecpanse1 = EcpanseLocalServiceUtil.getEcpanse(Long.valueOf(companyId));
				
			} catch (NumberFormatException | PortalException e) {
				// TODO: handle exception
			}
			renderRequest.setAttribute("ecpanse1", ecpanse1);
		}
		super.render(renderRequest, renderResponse);
	}
	public void addExpanse(ActionRequest actionRequest,ActionResponse response){
		 long companyId = ParamUtil.getLong(actionRequest, "companyId");
		 String name= ParamUtil.getString(actionRequest, "name");
		 long categoryId= ParamUtil.getInteger(actionRequest, "categoryId");
		 
		 System.out.println("company name is "+name);
		 System.out.println("categoryID is " +categoryId);
		 System.out.println("companyId:::::"+companyId);
		 Ecpanse ecpanse = null;
		 if (companyId > 0) {
			 
		 try {
			 ecpanse = EcpanseLocalServiceUtil.getEcpanse(companyId);
			} catch (PortalException e) {
				e.printStackTrace();
			}
		 ecpanse.setName(name);
		 ecpanse.setCategoryId(categoryId);
			EcpanseLocalServiceUtil.updateEcpanse(ecpanse);
			 
		 }else {
			 
			 ecpanse = EcpanseLocalServiceUtil.createEcpanse(companyId);
			 ecpanse.setName(name);
			 ecpanse.setCategoryId(categoryId);
			/* EcpanseLocalServiceUtil.updateEcpanse(ecpanse);*/
			 EcpanseLocalServiceUtil.addEcpanse(ecpanse);
		 }
				 
		   	 
	}
	public void edit(RenderRequest renderRequest,RenderResponse renderResponse){
		System.out.println("rendering");
		
	}
	

	
	public void delete_Expanse(ActionRequest actionRequest,ActionResponse response){
		
		 long companyId = ParamUtil.getLong(actionRequest, "companyId");
		 System.out.println("projectId::inside delete project:::"+companyId);
		 Ecpanse espance1 = null;
		 if(companyId > 0) {
			 try {
				 EcpanseLocalServiceUtil.deleteEcpanse(companyId);
			} catch (PortalException e) {
				e.printStackTrace();
			}
		 }
		 System.out.println("companyId Expanse delete successfully");
		 
	}
	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
		System.out.println("Serve Resource Called");
		super.serveResource(resourceRequest, resourceResponse);
	}
}