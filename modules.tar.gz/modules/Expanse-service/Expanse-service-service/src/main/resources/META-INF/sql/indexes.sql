create index IX_8B53CA1D on FOO_Ecpanse (name[$COLUMN_LENGTH:75$]);
create index IX_DEE95F52 on FOO_Ecpanse (uuid_[$COLUMN_LENGTH:75$], companyId);