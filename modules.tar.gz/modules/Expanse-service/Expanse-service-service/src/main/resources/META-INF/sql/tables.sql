create table FOO_Ecpanse (
	uuid_ VARCHAR(75) null,
	companyId LONG not null primary key,
	name VARCHAR(75) null,
	categoryId LONG
);