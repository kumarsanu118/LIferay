/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.exp.model.impl;

import aQute.bnd.annotation.ProviderType;

import com.exp.model.Ecpanse;

import com.liferay.portal.kernel.model.CacheModel;
import com.liferay.portal.kernel.util.HashUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Ecpanse in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see Ecpanse
 * @generated
 */
@ProviderType
public class EcpanseCacheModel implements CacheModel<Ecpanse>, Externalizable {
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EcpanseCacheModel)) {
			return false;
		}

		EcpanseCacheModel ecpanseCacheModel = (EcpanseCacheModel)obj;

		if (companyId == ecpanseCacheModel.companyId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, companyId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(9);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", name=");
		sb.append(name);
		sb.append(", categoryId=");
		sb.append(categoryId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Ecpanse toEntityModel() {
		EcpanseImpl ecpanseImpl = new EcpanseImpl();

		if (uuid == null) {
			ecpanseImpl.setUuid(StringPool.BLANK);
		}
		else {
			ecpanseImpl.setUuid(uuid);
		}

		ecpanseImpl.setCompanyId(companyId);

		if (name == null) {
			ecpanseImpl.setName(StringPool.BLANK);
		}
		else {
			ecpanseImpl.setName(name);
		}

		ecpanseImpl.setCategoryId(categoryId);

		ecpanseImpl.resetOriginalValues();

		return ecpanseImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		companyId = objectInput.readLong();
		name = objectInput.readUTF();

		categoryId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(companyId);

		if (name == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(name);
		}

		objectOutput.writeLong(categoryId);
	}

	public String uuid;
	public long companyId;
	public String name;
	public long categoryId;
}