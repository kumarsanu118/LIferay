/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.exp.service;

import aQute.bnd.annotation.ProviderType;

import com.liferay.osgi.util.ServiceTrackerFactory;

import org.osgi.util.tracker.ServiceTracker;

/**
 * Provides the local service utility for Ecpanse. This utility wraps
 * {@link com.exp.service.impl.EcpanseLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see EcpanseLocalService
 * @see com.exp.service.base.EcpanseLocalServiceBaseImpl
 * @see com.exp.service.impl.EcpanseLocalServiceImpl
 * @generated
 */
@ProviderType
public class EcpanseLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.exp.service.impl.EcpanseLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the ecpanse to the database. Also notifies the appropriate model listeners.
	*
	* @param ecpanse the ecpanse
	* @return the ecpanse that was added
	*/
	public static com.exp.model.Ecpanse addEcpanse(
		com.exp.model.Ecpanse ecpanse) {
		return getService().addEcpanse(ecpanse);
	}

	/**
	* Creates a new ecpanse with the primary key. Does not add the ecpanse to the database.
	*
	* @param companyId the primary key for the new ecpanse
	* @return the new ecpanse
	*/
	public static com.exp.model.Ecpanse createEcpanse(long companyId) {
		return getService().createEcpanse(companyId);
	}

	/**
	* Deletes the ecpanse from the database. Also notifies the appropriate model listeners.
	*
	* @param ecpanse the ecpanse
	* @return the ecpanse that was removed
	*/
	public static com.exp.model.Ecpanse deleteEcpanse(
		com.exp.model.Ecpanse ecpanse) {
		return getService().deleteEcpanse(ecpanse);
	}

	/**
	* Deletes the ecpanse with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param companyId the primary key of the ecpanse
	* @return the ecpanse that was removed
	* @throws PortalException if a ecpanse with the primary key could not be found
	*/
	public static com.exp.model.Ecpanse deleteEcpanse(long companyId)
		throws com.liferay.portal.kernel.exception.PortalException {
		return getService().deleteEcpanse(companyId);
	}

	public static com.exp.model.Ecpanse fetchEcpanse(long companyId) {
		return getService().fetchEcpanse(companyId);
	}

	/**
	* Returns the ecpanse with the matching UUID and company.
	*
	* @param uuid the ecpanse's UUID
	* @param companyId the primary key of the company
	* @return the matching ecpanse, or <code>null</code> if a matching ecpanse could not be found
	*/
	public static com.exp.model.Ecpanse fetchEcpanseByUuidAndCompanyId(
		java.lang.String uuid, long companyId) {
		return getService().fetchEcpanseByUuidAndCompanyId(uuid, companyId);
	}

	/**
	* Returns the ecpanse with the primary key.
	*
	* @param companyId the primary key of the ecpanse
	* @return the ecpanse
	* @throws PortalException if a ecpanse with the primary key could not be found
	*/
	public static com.exp.model.Ecpanse getEcpanse(long companyId)
		throws com.liferay.portal.kernel.exception.PortalException {
		return getService().getEcpanse(companyId);
	}

	/**
	* Returns the ecpanse with the matching UUID and company.
	*
	* @param uuid the ecpanse's UUID
	* @param companyId the primary key of the company
	* @return the matching ecpanse
	* @throws PortalException if a matching ecpanse could not be found
	*/
	public static com.exp.model.Ecpanse getEcpanseByUuidAndCompanyId(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.PortalException {
		return getService().getEcpanseByUuidAndCompanyId(uuid, companyId);
	}

	/**
	* Updates the ecpanse in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param ecpanse the ecpanse
	* @return the ecpanse that was updated
	*/
	public static com.exp.model.Ecpanse updateEcpanse(
		com.exp.model.Ecpanse ecpanse) {
		return getService().updateEcpanse(ecpanse);
	}

	public static com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery getActionableDynamicQuery() {
		return getService().getActionableDynamicQuery();
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	public static com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery getIndexableActionableDynamicQuery() {
		return getService().getIndexableActionableDynamicQuery();
	}

	/**
	* @throws PortalException
	*/
	public static com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
		com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {
		return getService().deletePersistedModel(persistedModel);
	}

	public static com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns the number of ecpanses.
	*
	* @return the number of ecpanses
	*/
	public static int getEcpansesCount() {
		return getService().getEcpansesCount();
	}

	/**
	* Returns the OSGi service identifier.
	*
	* @return the OSGi service identifier
	*/
	public static java.lang.String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	*/
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.exp.model.impl.EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	*/
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.exp.model.impl.EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	*/
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns a range of all the ecpanses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.exp.model.impl.EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @return the range of ecpanses
	*/
	public static java.util.List<com.exp.model.Ecpanse> getEcpanses(int start,
		int end) {
		return getService().getEcpanses(start, end);
	}

	public static java.util.List<com.exp.model.Ecpanse> getProjectBycompanyName(
		java.lang.String Name) {
		return getService().getProjectBycompanyName(Name);
	}

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows matching the dynamic query
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows matching the dynamic query
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static EcpanseLocalService getService() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<EcpanseLocalService, EcpanseLocalService> _serviceTracker =
		ServiceTrackerFactory.open(EcpanseLocalService.class);
}