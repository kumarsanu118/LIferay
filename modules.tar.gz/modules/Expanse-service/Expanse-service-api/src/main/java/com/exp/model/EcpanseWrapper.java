/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.exp.model;

import aQute.bnd.annotation.ProviderType;

import com.liferay.expando.kernel.model.ExpandoBridge;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.service.ServiceContext;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * This class is a wrapper for {@link Ecpanse}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Ecpanse
 * @generated
 */
@ProviderType
public class EcpanseWrapper implements Ecpanse, ModelWrapper<Ecpanse> {
	public EcpanseWrapper(Ecpanse ecpanse) {
		_ecpanse = ecpanse;
	}

	@Override
	public Class<?> getModelClass() {
		return Ecpanse.class;
	}

	@Override
	public String getModelClassName() {
		return Ecpanse.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("companyId", getCompanyId());
		attributes.put("name", getName());
		attributes.put("categoryId", getCategoryId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		String name = (String)attributes.get("name");

		if (name != null) {
			setName(name);
		}

		Long categoryId = (Long)attributes.get("categoryId");

		if (categoryId != null) {
			setCategoryId(categoryId);
		}
	}

	@Override
	public Ecpanse toEscapedModel() {
		return new EcpanseWrapper(_ecpanse.toEscapedModel());
	}

	@Override
	public Ecpanse toUnescapedModel() {
		return new EcpanseWrapper(_ecpanse.toUnescapedModel());
	}

	@Override
	public boolean isCachedModel() {
		return _ecpanse.isCachedModel();
	}

	@Override
	public boolean isEscapedModel() {
		return _ecpanse.isEscapedModel();
	}

	@Override
	public boolean isNew() {
		return _ecpanse.isNew();
	}

	@Override
	public ExpandoBridge getExpandoBridge() {
		return _ecpanse.getExpandoBridge();
	}

	@Override
	public com.liferay.portal.kernel.model.CacheModel<Ecpanse> toCacheModel() {
		return _ecpanse.toCacheModel();
	}

	@Override
	public int compareTo(Ecpanse ecpanse) {
		return _ecpanse.compareTo(ecpanse);
	}

	@Override
	public int hashCode() {
		return _ecpanse.hashCode();
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _ecpanse.getPrimaryKeyObj();
	}

	@Override
	public java.lang.Object clone() {
		return new EcpanseWrapper((Ecpanse)_ecpanse.clone());
	}

	/**
	* Returns the name of this ecpanse.
	*
	* @return the name of this ecpanse
	*/
	@Override
	public java.lang.String getName() {
		return _ecpanse.getName();
	}

	/**
	* Returns the uuid of this ecpanse.
	*
	* @return the uuid of this ecpanse
	*/
	@Override
	public java.lang.String getUuid() {
		return _ecpanse.getUuid();
	}

	@Override
	public java.lang.String toString() {
		return _ecpanse.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _ecpanse.toXmlString();
	}

	/**
	* Returns the category ID of this ecpanse.
	*
	* @return the category ID of this ecpanse
	*/
	@Override
	public long getCategoryId() {
		return _ecpanse.getCategoryId();
	}

	/**
	* Returns the company ID of this ecpanse.
	*
	* @return the company ID of this ecpanse
	*/
	@Override
	public long getCompanyId() {
		return _ecpanse.getCompanyId();
	}

	/**
	* Returns the primary key of this ecpanse.
	*
	* @return the primary key of this ecpanse
	*/
	@Override
	public long getPrimaryKey() {
		return _ecpanse.getPrimaryKey();
	}

	@Override
	public void persist() {
		_ecpanse.persist();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_ecpanse.setCachedModel(cachedModel);
	}

	/**
	* Sets the category ID of this ecpanse.
	*
	* @param categoryId the category ID of this ecpanse
	*/
	@Override
	public void setCategoryId(long categoryId) {
		_ecpanse.setCategoryId(categoryId);
	}

	/**
	* Sets the company ID of this ecpanse.
	*
	* @param companyId the company ID of this ecpanse
	*/
	@Override
	public void setCompanyId(long companyId) {
		_ecpanse.setCompanyId(companyId);
	}

	@Override
	public void setExpandoBridgeAttributes(ExpandoBridge expandoBridge) {
		_ecpanse.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.kernel.model.BaseModel<?> baseModel) {
		_ecpanse.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(ServiceContext serviceContext) {
		_ecpanse.setExpandoBridgeAttributes(serviceContext);
	}

	/**
	* Sets the name of this ecpanse.
	*
	* @param name the name of this ecpanse
	*/
	@Override
	public void setName(java.lang.String name) {
		_ecpanse.setName(name);
	}

	@Override
	public void setNew(boolean n) {
		_ecpanse.setNew(n);
	}

	/**
	* Sets the primary key of this ecpanse.
	*
	* @param primaryKey the primary key of this ecpanse
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_ecpanse.setPrimaryKey(primaryKey);
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		_ecpanse.setPrimaryKeyObj(primaryKeyObj);
	}

	/**
	* Sets the uuid of this ecpanse.
	*
	* @param uuid the uuid of this ecpanse
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_ecpanse.setUuid(uuid);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EcpanseWrapper)) {
			return false;
		}

		EcpanseWrapper ecpanseWrapper = (EcpanseWrapper)obj;

		if (Objects.equals(_ecpanse, ecpanseWrapper._ecpanse)) {
			return true;
		}

		return false;
	}

	@Override
	public Ecpanse getWrappedModel() {
		return _ecpanse;
	}

	@Override
	public boolean isEntityCacheEnabled() {
		return _ecpanse.isEntityCacheEnabled();
	}

	@Override
	public boolean isFinderCacheEnabled() {
		return _ecpanse.isFinderCacheEnabled();
	}

	@Override
	public void resetOriginalValues() {
		_ecpanse.resetOriginalValues();
	}

	private final Ecpanse _ecpanse;
}