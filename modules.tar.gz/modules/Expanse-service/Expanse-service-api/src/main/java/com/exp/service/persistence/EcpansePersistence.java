/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.exp.service.persistence;

import aQute.bnd.annotation.ProviderType;

import com.exp.exception.NoSuchEcpanseException;

import com.exp.model.Ecpanse;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

/**
 * The persistence interface for the ecpanse service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see com.exp.service.persistence.impl.EcpansePersistenceImpl
 * @see EcpanseUtil
 * @generated
 */
@ProviderType
public interface EcpansePersistence extends BasePersistence<Ecpanse> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link EcpanseUtil} to access the ecpanse persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the ecpanses where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching ecpanses
	*/
	public java.util.List<Ecpanse> findByUuid(java.lang.String uuid);

	/**
	* Returns a range of all the ecpanses where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @return the range of matching ecpanses
	*/
	public java.util.List<Ecpanse> findByUuid(java.lang.String uuid, int start,
		int end);

	/**
	* Returns an ordered range of all the ecpanses where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching ecpanses
	*/
	public java.util.List<Ecpanse> findByUuid(java.lang.String uuid, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator);

	/**
	* Returns an ordered range of all the ecpanses where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching ecpanses
	*/
	public java.util.List<Ecpanse> findByUuid(java.lang.String uuid, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator,
		boolean retrieveFromCache);

	/**
	* Returns the first ecpanse in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching ecpanse
	* @throws NoSuchEcpanseException if a matching ecpanse could not be found
	*/
	public Ecpanse findByUuid_First(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator)
		throws NoSuchEcpanseException;

	/**
	* Returns the first ecpanse in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching ecpanse, or <code>null</code> if a matching ecpanse could not be found
	*/
	public Ecpanse fetchByUuid_First(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator);

	/**
	* Returns the last ecpanse in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching ecpanse
	* @throws NoSuchEcpanseException if a matching ecpanse could not be found
	*/
	public Ecpanse findByUuid_Last(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator)
		throws NoSuchEcpanseException;

	/**
	* Returns the last ecpanse in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching ecpanse, or <code>null</code> if a matching ecpanse could not be found
	*/
	public Ecpanse fetchByUuid_Last(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator);

	/**
	* Returns the ecpanses before and after the current ecpanse in the ordered set where uuid = &#63;.
	*
	* @param companyId the primary key of the current ecpanse
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next ecpanse
	* @throws NoSuchEcpanseException if a ecpanse with the primary key could not be found
	*/
	public Ecpanse[] findByUuid_PrevAndNext(long companyId,
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator)
		throws NoSuchEcpanseException;

	/**
	* Removes all the ecpanses where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	*/
	public void removeByUuid(java.lang.String uuid);

	/**
	* Returns the number of ecpanses where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching ecpanses
	*/
	public int countByUuid(java.lang.String uuid);

	/**
	* Returns all the ecpanses where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching ecpanses
	*/
	public java.util.List<Ecpanse> findByUuid_C(java.lang.String uuid,
		long companyId);

	/**
	* Returns a range of all the ecpanses where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @return the range of matching ecpanses
	*/
	public java.util.List<Ecpanse> findByUuid_C(java.lang.String uuid,
		long companyId, int start, int end);

	/**
	* Returns an ordered range of all the ecpanses where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching ecpanses
	*/
	public java.util.List<Ecpanse> findByUuid_C(java.lang.String uuid,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator);

	/**
	* Returns an ordered range of all the ecpanses where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching ecpanses
	*/
	public java.util.List<Ecpanse> findByUuid_C(java.lang.String uuid,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator,
		boolean retrieveFromCache);

	/**
	* Returns the first ecpanse in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching ecpanse
	* @throws NoSuchEcpanseException if a matching ecpanse could not be found
	*/
	public Ecpanse findByUuid_C_First(java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator)
		throws NoSuchEcpanseException;

	/**
	* Returns the first ecpanse in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching ecpanse, or <code>null</code> if a matching ecpanse could not be found
	*/
	public Ecpanse fetchByUuid_C_First(java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator);

	/**
	* Returns the last ecpanse in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching ecpanse
	* @throws NoSuchEcpanseException if a matching ecpanse could not be found
	*/
	public Ecpanse findByUuid_C_Last(java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator)
		throws NoSuchEcpanseException;

	/**
	* Returns the last ecpanse in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching ecpanse, or <code>null</code> if a matching ecpanse could not be found
	*/
	public Ecpanse fetchByUuid_C_Last(java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator);

	/**
	* Removes all the ecpanses where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	*/
	public void removeByUuid_C(java.lang.String uuid, long companyId);

	/**
	* Returns the number of ecpanses where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching ecpanses
	*/
	public int countByUuid_C(java.lang.String uuid, long companyId);

	/**
	* Returns all the ecpanses where name = &#63;.
	*
	* @param name the name
	* @return the matching ecpanses
	*/
	public java.util.List<Ecpanse> findByName(java.lang.String name);

	/**
	* Returns a range of all the ecpanses where name = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param name the name
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @return the range of matching ecpanses
	*/
	public java.util.List<Ecpanse> findByName(java.lang.String name, int start,
		int end);

	/**
	* Returns an ordered range of all the ecpanses where name = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param name the name
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching ecpanses
	*/
	public java.util.List<Ecpanse> findByName(java.lang.String name, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator);

	/**
	* Returns an ordered range of all the ecpanses where name = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param name the name
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching ecpanses
	*/
	public java.util.List<Ecpanse> findByName(java.lang.String name, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator,
		boolean retrieveFromCache);

	/**
	* Returns the first ecpanse in the ordered set where name = &#63;.
	*
	* @param name the name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching ecpanse
	* @throws NoSuchEcpanseException if a matching ecpanse could not be found
	*/
	public Ecpanse findByName_First(java.lang.String name,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator)
		throws NoSuchEcpanseException;

	/**
	* Returns the first ecpanse in the ordered set where name = &#63;.
	*
	* @param name the name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching ecpanse, or <code>null</code> if a matching ecpanse could not be found
	*/
	public Ecpanse fetchByName_First(java.lang.String name,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator);

	/**
	* Returns the last ecpanse in the ordered set where name = &#63;.
	*
	* @param name the name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching ecpanse
	* @throws NoSuchEcpanseException if a matching ecpanse could not be found
	*/
	public Ecpanse findByName_Last(java.lang.String name,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator)
		throws NoSuchEcpanseException;

	/**
	* Returns the last ecpanse in the ordered set where name = &#63;.
	*
	* @param name the name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching ecpanse, or <code>null</code> if a matching ecpanse could not be found
	*/
	public Ecpanse fetchByName_Last(java.lang.String name,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator);

	/**
	* Returns the ecpanses before and after the current ecpanse in the ordered set where name = &#63;.
	*
	* @param companyId the primary key of the current ecpanse
	* @param name the name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next ecpanse
	* @throws NoSuchEcpanseException if a ecpanse with the primary key could not be found
	*/
	public Ecpanse[] findByName_PrevAndNext(long companyId,
		java.lang.String name,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator)
		throws NoSuchEcpanseException;

	/**
	* Removes all the ecpanses where name = &#63; from the database.
	*
	* @param name the name
	*/
	public void removeByName(java.lang.String name);

	/**
	* Returns the number of ecpanses where name = &#63;.
	*
	* @param name the name
	* @return the number of matching ecpanses
	*/
	public int countByName(java.lang.String name);

	/**
	* Caches the ecpanse in the entity cache if it is enabled.
	*
	* @param ecpanse the ecpanse
	*/
	public void cacheResult(Ecpanse ecpanse);

	/**
	* Caches the ecpanses in the entity cache if it is enabled.
	*
	* @param ecpanses the ecpanses
	*/
	public void cacheResult(java.util.List<Ecpanse> ecpanses);

	/**
	* Creates a new ecpanse with the primary key. Does not add the ecpanse to the database.
	*
	* @param companyId the primary key for the new ecpanse
	* @return the new ecpanse
	*/
	public Ecpanse create(long companyId);

	/**
	* Removes the ecpanse with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param companyId the primary key of the ecpanse
	* @return the ecpanse that was removed
	* @throws NoSuchEcpanseException if a ecpanse with the primary key could not be found
	*/
	public Ecpanse remove(long companyId) throws NoSuchEcpanseException;

	public Ecpanse updateImpl(Ecpanse ecpanse);

	/**
	* Returns the ecpanse with the primary key or throws a {@link NoSuchEcpanseException} if it could not be found.
	*
	* @param companyId the primary key of the ecpanse
	* @return the ecpanse
	* @throws NoSuchEcpanseException if a ecpanse with the primary key could not be found
	*/
	public Ecpanse findByPrimaryKey(long companyId)
		throws NoSuchEcpanseException;

	/**
	* Returns the ecpanse with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param companyId the primary key of the ecpanse
	* @return the ecpanse, or <code>null</code> if a ecpanse with the primary key could not be found
	*/
	public Ecpanse fetchByPrimaryKey(long companyId);

	@Override
	public java.util.Map<java.io.Serializable, Ecpanse> fetchByPrimaryKeys(
		java.util.Set<java.io.Serializable> primaryKeys);

	/**
	* Returns all the ecpanses.
	*
	* @return the ecpanses
	*/
	public java.util.List<Ecpanse> findAll();

	/**
	* Returns a range of all the ecpanses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @return the range of ecpanses
	*/
	public java.util.List<Ecpanse> findAll(int start, int end);

	/**
	* Returns an ordered range of all the ecpanses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of ecpanses
	*/
	public java.util.List<Ecpanse> findAll(int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator);

	/**
	* Returns an ordered range of all the ecpanses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link EcpanseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of ecpanses
	* @param end the upper bound of the range of ecpanses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of ecpanses
	*/
	public java.util.List<Ecpanse> findAll(int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Ecpanse> orderByComparator,
		boolean retrieveFromCache);

	/**
	* Removes all the ecpanses from the database.
	*/
	public void removeAll();

	/**
	* Returns the number of ecpanses.
	*
	* @return the number of ecpanses
	*/
	public int countAll();

	@Override
	public java.util.Set<java.lang.String> getBadColumnNames();
}