package com.sal.constants;

/**
 * @author e2
 */
public class SalaryBreakupPortletKeys {

	public static final String SalaryBreakup = "SalaryBreakup";

}