package com.sal.ActionCommand;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;


import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.sal.constants.SalaryBreakupPortletKeys;
import com.sal.model.General_sal;
import com.sal.service.General_salLocalService;
import com.sal.service.General_salLocalServiceUtil;
@Component(
		 property = {
		 "javax.portlet.name=" + SalaryBreakupPortletKeys.SalaryBreakup,
		 "mvc.command.name=saveSalaryDetails"
		 },
		 service = MVCActionCommand.class
		 )
public class SalaryActionCommand extends BaseMVCActionCommand {
	private General_salLocalService general_salLocalService;
	@Reference(unbind = "-")
	protected void setexpanseService(General_salLocalService general_salLocalService){
		this.general_salLocalService=general_salLocalService;
	}
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		long employeeId=ParamUtil.getLong(actionRequest, "employeeId");
		String breakUpType = ParamUtil.getString(actionRequest, "breakUpType");
		long amount =ParamUtil.getLong(actionRequest, "amount");
		General_sal general_sal = General_salLocalServiceUtil.createGeneral_sal(CounterLocalServiceUtil.increment());
		general_sal.setEmployeeId(employeeId);
		general_sal.setBreakUpType(breakUpType);
		general_sal.setAmount(amount);
		General_salLocalServiceUtil.updateGeneral_sal(general_sal);
	}
}
