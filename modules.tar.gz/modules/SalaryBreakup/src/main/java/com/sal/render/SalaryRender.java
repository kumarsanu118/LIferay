package com.sal.render;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.sal.constants.SalaryBreakupPortletKeys;
@Component(property = { "javax.portlet.name=" + SalaryBreakupPortletKeys.SalaryBreakup,
"mvc.command.name=show_values" }, service = MVCRenderCommand.class)
public class SalaryRender implements MVCRenderCommand {
	public final static String SHOW_VALUES = "/show_values.jsp";
	public final static String ERROR = "/error.jsp";
	
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		System.out.println("in ShowVal ");
		try {
			long employeeId = ParamUtil.getLong(renderRequest, "employeeId");
			System.out.println("name::::::" + employeeId);
			renderRequest.setAttribute("name", employeeId);
		} catch (Exception e) {
			return ERROR;
		}

		return SHOW_VALUES;
	}
		}

