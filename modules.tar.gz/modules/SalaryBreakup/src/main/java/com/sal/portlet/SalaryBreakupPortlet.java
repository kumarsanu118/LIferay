package com.sal.portlet;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;

import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;
import com.sal.constants.SalaryBreakupPortletKeys;
import com.sal.model.General_sal;
import com.sal.service.General_salLocalServiceUtil;

/**
 * @author e2
 */
@Component(
		immediate = true,
		property = {
				"com.liferay.portlet.display-category=category.sample",
				"com.liferay.portlet.instanceable=true",
				"javax.portlet.display-name=SalaryBreakup Portlet",
				"javax.portlet.init-param.template-path=/",
				"javax.portlet.init-param.view-template=/view.jsp",
				"javax.portlet.name=" + SalaryBreakupPortletKeys.SalaryBreakup,
				"javax.portlet.resource-bundle=content.Language",
				"javax.portlet.security-role-ref=power-user,user"
		},
		service = Portlet.class
		)
public class SalaryBreakupPortlet extends MVCPortlet {
	static long employeeId;
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
	   List<General_sal> general_sal = General_salLocalServiceUtil.getProjectByemployeeId(employeeId);
		renderRequest.setAttribute("general_sal", general_sal);
		String salaryId = ParamUtil.getString(renderRequest, "salaryId");
		if (salaryId != null){
			General_sal general =null;
			try {
				general = General_salLocalServiceUtil.getGeneral_sal(Long.valueOf(salaryId));
			} catch (NumberFormatException | PortalException e) {
				// TODO: handle exception
			}
			renderRequest.setAttribute("general", general);
		}
		super.render(renderRequest, renderResponse);
	}

	public void addsalary(ActionRequest actionRequest,ActionResponse response) {

		long salaryId = ParamUtil.getLong(actionRequest, "salaryId");
		long employeeId =ParamUtil.getLong(actionRequest," employeeId");
		String breakUpType = ParamUtil.getString(actionRequest, "breakUpType");
		long amount = ParamUtil.getLong(actionRequest, "amount");
		System.out.println("salary id is "+salaryId);
		System.out.println("employee id "+employeeId);
		System.out.println("salary type "+breakUpType);
		System.out.println("salary ammount is "+amount);

		General_sal general =null;
		if(salaryId > 0){
			try {
				general=General_salLocalServiceUtil.getGeneral_sal(salaryId);


			} catch (PortalException e) {
				e.printStackTrace();
			}
			general.setEmployeeId(employeeId);
			general.setBreakUpType(breakUpType);
			general.setAmount(amount);
			General_salLocalServiceUtil.updateGeneral_sal(general);

		} else  {
			general = General_salLocalServiceUtil.createGeneral_sal(0);
			general.setEmployeeId(employeeId);
			general.setBreakUpType(breakUpType);
			general.setAmount(amount);
			General_salLocalServiceUtil.updateGeneral_sal(general);


		}
	}
		public void edit(RenderRequest renderRequest,RenderResponse renderResponse){
			System.out.println("rendering");
			

	}
	public void delete_Salary(ActionRequest actionRequest,ActionResponse response){
		
		 long salaryId = ParamUtil.getLong(actionRequest, "salaryId");
		 System.out.println("projectId::inside delete project:::"+salaryId);
		 General_sal general = null;
		 if(salaryId > 0) {
			 try {
				 General_salLocalServiceUtil.deleteGeneral_sal(salaryId);
			} catch (PortalException e) {
				e.printStackTrace();
			}
		 }
		 System.out.println("Salary  delete successfully");
		 
	}
	
	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
		System.out.println("Serve Resource Called");
		super.serveResource(resourceRequest, resourceResponse);
	}
}

